package com.moath.timetable

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject
import androidx.compose.ui.unit.LayoutDirection

private val Navy = Color(0xFF0D3B66)
private val Teal = Color(0xFF1B998B)
private val Sand = Color(0xFFF4F1EA)
private val Gold = Color(0xFFF4B942)

private val days = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
private val dayColors = listOf(
    Color(0xFF1B998B), Color(0xFF3A86FF), Color(0xFF8338EC), Color(0xFFFF006E),
    Color(0xFFFB5607), Color(0xFF2A9D8F), Color(0xFFE9A800)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Teal)) {
                    var showSplash by remember { mutableStateOf(true) }
                    Crossfade(showSplash, label = "screen") { splash ->
                        if (splash) WelcomeScreen { showSplash = false } else TimetableScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun WelcomeScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(3500); onDone() }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, Teal)))
            .clickable { onDone() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Icon(Icons.Filled.DateRange, null, tint = Gold, modifier = Modifier.size(96.dp))
            Spacer(Modifier.height(16.dp))
            Text("جدول الحصص", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.width(80.dp).height(3.dp).background(Gold))
            Spacer(Modifier.height(24.dp))
            Text(
                "عمل و تصميم المعلم معاذ العمري\nمن مدرسة الملك عبدالله الثاني للتميز / اربد",
                color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center, lineHeight = 30.sp
            )
            Spacer(Modifier.height(40.dp))
            Text("اضغط للمتابعة", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
        }
    }
}

private fun load(ctx: Context): Pair<Map<String, String>, Triple<String, String, String>> {
    val p = ctx.getSharedPreferences("timetable", Context.MODE_PRIVATE)
    val map = mutableMapOf<String, String>()
    runCatching {
        val o = JSONObject(p.getString("cells", "{}")!!)
        o.keys().forEach { map[it] = o.getString(it) }
    }
    return map to Triple(p.getString("school", "") ?: "", p.getString("teacher", "") ?: "", p.getString("subject", "") ?: "")
}

private fun persist(ctx: Context, cells: Map<String, String>, info: Triple<String, String, String>) {
    val o = JSONObject()
    cells.forEach { (k, v) -> if (v.isNotBlank()) o.put(k, v) }
    ctx.getSharedPreferences("timetable", Context.MODE_PRIVATE).edit()
        .putString("cells", o.toString())
        .putString("school", info.first).putString("teacher", info.second).putString("subject", info.third)
        .apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen() {
    val ctx = LocalContext.current
    val loaded = remember { load(ctx) }

    var savedCells by remember { mutableStateOf(loaded.first) }
    var savedInfo by remember { mutableStateOf(loaded.second) }
    val cells = remember { mutableStateMapOf<String, String>().apply { putAll(loaded.first) } }
    var school by remember { mutableStateOf(loaded.second.first) }
    var teacher by remember { mutableStateOf(loaded.second.second) }
    var subject by remember { mutableStateOf(loaded.second.third) }

    var infoOpen by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val snack = remember { SnackbarHostState() }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) { message?.let { snack.showSnackbar(it); message = null } }

    val dirty = cells.filterValues { it.isNotBlank() } != savedCells.filterValues { it.isNotBlank() } ||
        Triple(school, teacher, subject) != savedInfo

    Scaffold(
        containerColor = Sand,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("جدول الحصص الأسبوعي", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White,
                    actionIconContentColor = Color.White),
                actions = {
                    // القائمة الأولى: بيانات المدرسة والمعلم والمادة
                    IconButton(onClick = { infoOpen = !infoOpen }) {
                        Icon(if (infoOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, "البيانات")
                    }
                    // القائمة الثانية: حفظ / إلغاء / مسح
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "خيارات") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("حفظ التعديلات") },
                                leadingIcon = { Icon(Icons.Filled.Check, null, tint = Teal) },
                                onClick = {
                                    menuOpen = false
                                    val info = Triple(school, teacher, subject)
                                    savedCells = cells.toMap(); savedInfo = info
                                    persist(ctx, savedCells, info)
                                    message = "تم حفظ التعديلات ✓"
                                })
                            DropdownMenuItem(
                                text = { Text("إلغاء التعديلات") },
                                leadingIcon = { Icon(Icons.Filled.Refresh, null, tint = Gold) },
                                onClick = {
                                    menuOpen = false
                                    cells.clear(); cells.putAll(savedCells)
                                    school = savedInfo.first; teacher = savedInfo.second; subject = savedInfo.third
                                    message = "تم إلغاء التعديلات"
                                })
                            DropdownMenuItem(
                                text = { Text("مسح الجدول") },
                                leadingIcon = { Icon(Icons.Filled.Delete, null, tint = Color(0xFFD62828)) },
                                onClick = { menuOpen = false; confirmClear = true })
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(12.dp)) {

            // لوحة الإدخال المنسدلة
            AnimatedVisibility(infoOpen) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoField("اسم المدرسة", school, Icons.Filled.Home) { school = it }
                        InfoField("اسم المعلم", teacher, Icons.Filled.Person) { teacher = it }
                        InfoField("اسم المادة", subject, Icons.Filled.Edit) { subject = it }
                    }
                }
            }

            // عرض البيانات على الشاشة
            Card(
                colors = CardDefaults.cardColors(containerColor = Navy),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(school.ifBlank { "اسم المدرسة" }, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        Text("المعلم: " + teacher.ifBlank { "—" }, color = Color.White, fontSize = 15.sp)
                        Text("المادة: " + subject.ifBlank { "—" }, color = Color.White, fontSize = 15.sp)
                    }
                    if (dirty) {
                        Spacer(Modifier.height(6.dp))
                        Text("● توجد تعديلات غير محفوظة", color = Gold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // الجدول
            val hScroll = rememberScrollState()
            val vScroll = rememberScrollState()
            Column(Modifier.fillMaxSize().verticalScroll(vScroll).horizontalScroll(hScroll)) {
                Row {
                    HeaderCell("اليوم / الحصة", 84, Navy)
                    (1..7).forEach { HeaderCell("الحصة $it", 96, Teal) }
                }
                days.forEachIndexed { d, day ->
                    Row {
                        HeaderCell(day, 84, dayColors[d])
                        (1..7).forEach { p ->
                            val text = cells["${d}_$p"].orEmpty()
                            Box(
                                Modifier.padding(2.dp).width(92.dp).height(64.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (text.isBlank()) Color.White else dayColors[d].copy(alpha = 0.14f))
                                    .border(1.dp, dayColors[d].copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                    .clickable { editing = d to p },
                                contentAlignment = Alignment.Center
                            ) {
                                if (text.isBlank())
                                    Icon(Icons.Filled.Add, null, tint = Color.LightGray)
                                else
                                    Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                                        maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(4.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    // نافذة تعديل الخلية
    editing?.let { (d, p) ->
        var value by remember(d, p) { mutableStateOf(cells["${d}_$p"].orEmpty()) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("${days[d]} - الحصة $p") },
            text = {
                OutlinedTextField(value, { value = it }, label = { Text("الاسم (صف / شعبة / نشاط)") },
                    singleLine = false, maxLines = 3, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = {
                    if (value.isBlank()) cells.remove("${d}_$p") else cells["${d}_$p"] = value.trim()
                    editing = null
                }) { Text("موافق") }
            },
            dismissButton = {
                TextButton(onClick = {
                    cells.remove("${d}_$p"); editing = null
                }) { Text("حذف") }
            }
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("مسح الجدول") },
            text = { Text("سيتم مسح جميع خلايا الجدول. يمكنك التراجع بخيار \"إلغاء التعديلات\" قبل الحفظ.") },
            confirmButton = {
                TextButton(onClick = { cells.clear(); confirmClear = false; message = "تم مسح الجدول" }) { Text("مسح") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("تراجع") } }
        )
    }
}

@Composable
private fun InfoField(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        leadingIcon = { Icon(icon, null, tint = Teal) }, singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun HeaderCell(text: String, width: Int, color: Color) {
    Box(
        Modifier.padding(2.dp).width((width - 4).dp).height(64.dp)
            .clip(RoundedCornerShape(10.dp)).background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}
