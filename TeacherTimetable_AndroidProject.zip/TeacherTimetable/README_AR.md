# بناء ملف APK (3 خطوات)

1. ثبّت Android Studio من developer.android.com/studio وافتح هذا المجلد (Open).
2. انتظر انتهاء Gradle Sync (يحتاج إنترنت لأول مرة).
3. من القائمة: Build ← Build Bundle(s) / APK(s) ← Build APK(s).
   ستجد الملف في: app/build/outputs/apk/debug/app-debug.apk

انقل الملف إلى الجوال وافتحه (فعّل "التثبيت من مصادر غير معروفة" عند الطلب).

---
# البناء التلقائي بدون حاسوب (GitHub Actions)

1. أنشئ حساباً على github.com ثم مستودعاً جديداً (New repository).
2. ارفع كل محتويات هذا المجلد، بما فيها المجلد المخفي .github (Add file ← Upload files).
3. افتح تبويب Actions وانتظر انتهاء Build APK (حوالي 5 دقائق)، أو شغّله يدوياً بزر Run workflow.
4. افتح التشغيل الناجح ونزّل الملف من قسم Artifacts باسم TeacherTimetable-APK.
